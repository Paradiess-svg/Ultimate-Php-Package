<?php
include '../koneksi.php';
function tambah_data($data, $files){

    $idtransaksi = $data['idtransaksi'];
    $idpesanan = $data['idpesanan'];
    $pesanan = $data['pesanan'];
    $total = $data['total'];
    $bayar = $data['bayar'];
    
    $query = "INSERT INTO transaksi VALUES('$idtransaksi', '$idpesanan', '$pesanan', '$total', '$bayar', )";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;
}

function ubah_data($data, $files){
    $idtransaksi = $data['idtransaksi'];
    $idpesanan = $data['idpesanan'];
    $pesanan = $data['pesanan'];
    $total = $data['total'];
    $bayar = $data['bayar'];

    $queryshow = "SELECT * FROM transaksi WHERE idtransaksi = '$idtransaksi';";
    $sqlshow = mysqli_query($GLOBALS['conn'], $queryshow);
    $result = mysqli_fetch_assoc($sqlshow);

    
    $query = "UPDATE transaksi SET idtransaksi='$idtransaksi', idpesanan = '$idpesanan', pesanan = '$pesanan', total = '$total', bayar = '$bayar' WHERE idtransaksi='$idtransaksi';";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;
}

function hapus_data($data){
    $idtransaksi = $data['hapus'];

    $queryshow = "SELECT * FROM transaksi WHERE idtransaksi = '$idtransaksi';";
    $sqlshow = mysqli_query($GLOBALS['conn'] , $queryshow);
    $result = mysqli_fetch_assoc($sqlshow);

    $query="DELETE FROM transaksi WHERE idtransaksi = '$idtransaksi' ;";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;

}

?>