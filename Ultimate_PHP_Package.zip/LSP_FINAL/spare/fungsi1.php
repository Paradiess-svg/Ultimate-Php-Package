<?php
include '../koneksi.php';
function tambah_data($data, $files){

    $nomor_meja = $data['nomor_meja'];
    $kapasitas = $data['kapasitas'];
    $status = $data['status'];
    $deskripsi = $data['deskripsi'];

    $query = "INSERT INTO meja VALUES('$nomor_meja', '$kapasitas', '$status', '$deskripsi')";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;
}

function ubah_data($data, $files){
    $nomor_meja = $data['nomor_meja'];
    $kapasitas = $data['kapasitas'];
    $status = $data['status'];
    $deskripsi = $data['deskripsi'];

    $queryshow = "SELECT * FROM meja WHERE nomor_meja = '$nomor_meja';";
    $sqlshow = mysqli_query($GLOBALS['conn'], $queryshow);
    $result = mysqli_fetch_assoc($sqlshow);

    
    $query = "UPDATE meja SET nomor_meja='$nomor_meja', kapasitas = '$kapasitas', status = '$status', deskripsi = '$deskripsi' WHERE nomor_meja='$nomor_meja';";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;
}

function hapus_data($data){
    $nomor_meja = $data['hapus'];

    $queryshow = "SELECT * FROM meja WHERE nomor_meja = '$nomor_meja';";
    $sqlshow = mysqli_query($GLOBALS['conn'] , $queryshow);
    $result = mysqli_fetch_assoc($sqlshow);

    $query="DELETE FROM meja WHERE nomor_meja = '$nomor_meja' ;";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;

}

?>