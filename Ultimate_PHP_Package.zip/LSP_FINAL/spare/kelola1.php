<!DOCTYPE html>

<?php
include '../koneksi.php';
session_start();


$nomor_meja = '';
$kapasitas = '';
$status ='';
$deskripsi = '';

if (isset($_GET['ubah'])) {
    $nomor_meja = $_GET['ubah'];

    $query = "SELECT * FROM meja WHERE nomor_meja = '$nomor_meja';";
    $sql = mysqli_query($conn, $query);

    $result = mysqli_fetch_assoc($sql);

    $nomor_meja = $result ['nomor_meja'];
    $kapasitas = $result ['kapasitas'];
    $status = $result ['status'];
    $deskripsi = $result ['deskripsi'];


    //var_dump($result);

    //die();
}
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../datatables/datatables.css">
    <script src="../datatables/datatables.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>


    <link rel="apple-touch-icon" sizes="180x180" href="asset/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="asset/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="asset/favicon-16x16.png">
<link rel="manifest" href="asset/site.webmanifest">

    <title>Admin Entri Meja</title>
</head>

<body>
    <nav class="navbar bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                Table Service
            </a>
        </div>
    </nav>
    <div class="container">
        <h1 class="mt-3">Admin Entri Meja</h1>

        <div class="container">
            <form method="post" action="proses1.php" enctype="multipart/form-data">
                <input type="hidden" value="<?php echo $nomor_meja?>" name="nomor_meja">
                <div class="mb-3 row">
                    <label for="nomor_meja" class="col-sm-2 col-form-label">Nomor Meja</label>
                    <div class="col-sm-10">
                        <?php if (isset($_GET['ubah'])) { ?>
                            <input required type="text" name="nomor_meja" class="form-control" id="nomor_meja" value="<?php echo $nomor_meja ?>" disabled>
                        <?php
                        } else{
                        ?>
                        <input required type="text" name="nomor_meja" class="form-control" id="nomor_meja" placeholder="Ex: 12" value="<?php echo $nomor_meja ?>">
                    <?php } ?>
                    </div>
                </div>

                <div class="mb-3 row">
                    <label for="nama" class="col-sm-2 col-form-label">Kapasitas</label>
                    <div class="col-sm-10">
                        <input required type="text" name="kapasitas" class="form-control" id="nama" placeholder="Ex: 8" value="<?php echo $kapasitas ?>">
                    </div>
                </div>

                <div class="mb-3 row">
                    <label for="jkel" class="col-sm-2 col-form-label">Status</label>
                    <div class="col-sm-10">
                        <select required id="jkel" name="status" class="form-select">
                            <option <?php if($status == 'Terisi') {echo "selected";} ?> value="Terisi">Terisi</option>
                            <option <?php if($status == 'Reserved') {echo "selected";} ?> value="Reserved">Reserved</option>
                            <option <?php if($status == 'Kosong') {echo "selected";} ?> value="Kosong">Kosong</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi</label>
                    <div class="col-sm-10">
                        <textarea required class="form-control" name="deskripsi" id="deskripsi" rows="3"><?php echo $deskripsi ?></textarea>
                    </div>
                </div>
                <div class="mb-3 row mt-3">
                    <div class="col">
                        <?php
                        if (isset($_GET['ubah'])) {
                        ?>
                            <button type="submit" name="aksi" value="edit" class="btn btn-primary"><i class="fa fa-floppy-o mx-1" aria-hidden="true"></i>Simpan Perubahan</button>
                        <?php
                        } else {
                        ?>
                            <button type="submit" name="aksi" value="add" class="btn btn-primary"><i class="fa fa-floppy-o mx-1" aria-hidden="true"></i>Tambah</button>
                        <?php
                        }
                        ?>
                        <a href="indexMeja.php" type="button" class="btn btn-danger"><i class="fa fa-reply mx-1" aria-hidden="true"></i>Batal</a>
                    </div>
            </form>
        </div>



        <h6>Hello mom</h6>
</body>

</html>