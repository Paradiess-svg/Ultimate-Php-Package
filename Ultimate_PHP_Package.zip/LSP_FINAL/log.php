<?php
                        session_start();

                        if ($_SESSION['level'] === 'admin') { header("location:admin/indexMeja.php"); }
                        elseif($_SESSION['level'] === 'kasir') { header("location:kasir/indexBill.php"); }
                        elseif($_SESSION['level'] === 'owner') { header("location:owner/indexLaporan.php"); }
                        elseif($_SESSION['level'] === 'waiter') { header("location:waiter/indexMenu.php"); }
                        else{header("location:login.php?pesan=gagal");
                        }?>
